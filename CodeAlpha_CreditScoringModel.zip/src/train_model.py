"""
train_model.py
---------------
TASK 1: CREDIT SCORING MODEL  (CodeAlpha Machine Learning Internship)

Predicts applicant creditworthiness (Good / Bad credit) from financial data.

Pipeline:
  1. Load data
  2. Preprocess (impute missing values, encode categoricals, scale numerics)
  3. Train 4 classifiers: Logistic Regression, Decision Tree, Random Forest,
     Gradient Boosting (sklearn's GradientBoostingClassifier, used in place of
     XGBoost since this offline environment cannot install the xgboost
     package — it is API-compatible and solves the same boosted-tree task;
     swap in `from xgboost import XGBClassifier` if you run this locally with
     `pip install xgboost`).
  4. Evaluate every model: Accuracy, Precision, Recall, F1, ROC-AUC
  5. Save: comparison table, confusion matrices, ROC curves, feature
     importance plot, and the best model (joblib .pkl)

Run with:  python src/train_model.py
"""

import warnings
warnings.filterwarnings("ignore")

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, ConfusionMatrixDisplay,
                              f1_score, precision_score, recall_score,
                              roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

sns.set_style("whitegrid")

# ---------------------------------------------------------------- 1. LOAD ---
df = pd.read_csv("data/credit_data.csv")
print(f"Loaded {len(df)} rows, {df.shape[1]} columns")
print("\nMissing values per column:\n", df.isna().sum()[df.isna().sum() > 0])

TARGET = "Creditworthiness"
y = (df[TARGET] == "Good").astype(int)   # Good=1, Bad=0
X = df.drop(columns=[TARGET])

numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
categorical_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()
print(f"\nNumeric features: {numeric_cols}")
print(f"Categorical features: {categorical_cols}")

# ------------------------------------------------------- 2. PREPROCESSING ---
preprocessor = ColumnTransformer([
    ("num", Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ]), numeric_cols),
    ("cat", Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ]), categorical_cols),
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)
print(f"\nTrain size: {len(X_train)}  |  Test size: {len(X_test)}")

# ------------------------------------------------------------- 3. MODELS ---
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "Decision Tree": DecisionTreeClassifier(max_depth=6, random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42),
    "Gradient Boosting (XGBoost-equivalent)": GradientBoostingClassifier(random_state=42),
}

results = []
roc_data = {}
fitted_pipelines = {}

for name, clf in models.items():
    pipe = Pipeline([("prep", preprocessor), ("clf", clf)])
    pipe.fit(X_train, y_train)
    fitted_pipelines[name] = pipe

    y_pred = pipe.predict(X_test)
    y_proba = pipe.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)

    results.append({"Model": name, "Accuracy": acc, "Precision": prec,
                     "Recall": rec, "F1": f1, "ROC_AUC": auc})

    fpr, tpr, _ = roc_curve(y_test, y_proba)
    roc_data[name] = (fpr, tpr, auc)

    # Confusion matrix plot per model
    fig, ax = plt.subplots(figsize=(4, 4))
    ConfusionMatrixDisplay.from_predictions(
        y_test, y_pred, display_labels=["Bad", "Good"], ax=ax, cmap="Blues"
    )
    ax.set_title(f"Confusion Matrix — {name}")
    plt.tight_layout()
    safe_name = name.split(" (")[0].replace(" ", "_").lower()
    plt.savefig(f"outputs/confusion_matrix_{safe_name}.png", dpi=150)
    plt.close()

results_df = pd.DataFrame(results).sort_values("ROC_AUC", ascending=False)
results_df.to_csv("outputs/model_comparison.csv", index=False)
print("\n=== Model Comparison (sorted by ROC-AUC) ===")
print(results_df.round(4).to_string(index=False))

# --------------------------------------------------------- ROC curve plot --
plt.figure(figsize=(6, 5))
for name, (fpr, tpr, auc) in roc_data.items():
    plt.plot(fpr, tpr, label=f"{name.split(' (')[0]} (AUC={auc:.3f})")
plt.plot([0, 1], [0, 1], "k--", alpha=0.4)
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curves — All Models")
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig("outputs/roc_curves.png", dpi=150)
plt.close()

# ------------------------------------------------- Feature importance plot --
best_name = results_df.iloc[0]["Model"]
best_pipe = fitted_pipelines[best_name]
best_clf = best_pipe.named_steps["clf"]

feature_names = (
    numeric_cols +
    list(best_pipe.named_steps["prep"]
         .named_transformers_["cat"]
         .named_steps["onehot"]
         .get_feature_names_out(categorical_cols))
)

if hasattr(best_clf, "feature_importances_"):
    importances = best_clf.feature_importances_
    imp_label = "Importance"
elif hasattr(best_clf, "coef_"):
    importances = np.abs(best_clf.coef_[0])
    imp_label = "|Coefficient|"
else:
    importances = None

if importances is not None:
    imp_df = pd.DataFrame({"feature": feature_names, "importance": importances})
    imp_df = imp_df.sort_values("importance", ascending=False).head(12)

    plt.figure(figsize=(7, 5))
    sns.barplot(data=imp_df, x="importance", y="feature", color="steelblue")
    plt.xlabel(imp_label)
    plt.title(f"Top Feature Importances — {best_name}")
    plt.tight_layout()
    plt.savefig("outputs/feature_importance.png", dpi=150)
    plt.close()

# ----------------------------------------------------------- Save model ----
joblib.dump(best_pipe, "outputs/best_model.pkl")
print(f"\nBest model: {best_name}  (ROC-AUC={results_df.iloc[0]['ROC_AUC']:.4f})")
print("Saved best model pipeline to outputs/best_model.pkl")
print("Saved comparison table, confusion matrices, ROC curves, and feature "
      "importance plot to outputs/")

"""
generate_dataset.py
--------------------
Generates a synthetic but realistic credit scoring dataset.

NOTE: No real-world dataset was provided with the task instructions, and this
environment has no internet access to download one (e.g. the UCI German
Credit Data or a Kaggle credit-scoring set). To keep the project fully
reproducible, this script generates a synthetic dataset using sensible
financial relationships (higher debt-to-income, poor payment history, and
short credit history reduce creditworthiness, etc.).

If you want to use a REAL dataset instead, replace this file's output
(data/credit_data.csv) with one downloaded from:
  - UCI German Credit Data: https://archive.ics.uci.edu/dataset/144/statlog+german+credit+data
  - Kaggle "Credit Score Classification" dataset
Just make sure the target column is named `Creditworthiness` with values
'Good'/'Bad', or update src/train_model.py accordingly.
"""

import numpy as np
import pandas as pd

np.random.seed(42)
N = 2000

age = np.random.randint(21, 65, N)
income = np.random.gamma(shape=5, scale=8000, size=N).round(2)          # annual income
employment_status = np.random.choice(
    ["Employed", "Self-Employed", "Unemployed", "Retired"],
    size=N, p=[0.6, 0.2, 0.1, 0.1]
)
employment_years = np.clip(
    (age - 21) * np.random.uniform(0.1, 0.9, N), 0, 40
).round(1)
credit_history_length = np.clip(
    np.random.normal(loc=8, scale=5, size=N), 0, 35
).round(1)  # years
num_dependents = np.random.poisson(1, N)
existing_loans = np.random.poisson(1.2, N)
debt = (income * np.random.uniform(0.05, 0.9, N) *
        (1 + 0.15 * existing_loans)).round(2)
loan_amount = np.random.gamma(shape=2, scale=4000, size=N).round(2)

# Payment history score: 0 (poor) - 100 (excellent), correlated with credit history & income
payment_history_score = np.clip(
    50 + credit_history_length * 1.2 - existing_loans * 4 +
    np.random.normal(0, 12, N), 0, 100
).round(1)

debt_to_income = (debt / np.clip(income, 1, None)).round(3)

# Missing data injection (to require preprocessing/imputation, as listed in the task)
for col, frac in [("employment_years", 0.03), ("payment_history_score", 0.02)]:
    idx = np.random.choice(N, size=int(N * frac), replace=False)
    if col == "employment_years":
        employment_years[idx] = np.nan
    else:
        payment_history_score[idx] = np.nan

df = pd.DataFrame({
    "Age": age,
    "AnnualIncome": income,
    "EmploymentStatus": employment_status,
    "EmploymentYears": employment_years,
    "CreditHistoryLength": credit_history_length,
    "NumDependents": num_dependents,
    "ExistingLoans": existing_loans,
    "Debt": debt,
    "DebtToIncome": debt_to_income,
    "LoanAmount": loan_amount,
    "PaymentHistoryScore": payment_history_score,
})

# --- Build a latent "creditworthiness" score from the features, then add noise ---
latent = (
    0.035 * df["PaymentHistoryScore"].fillna(df["PaymentHistoryScore"].mean())
    - 4.0 * df["DebtToIncome"]
    + 0.06 * df["CreditHistoryLength"]
    + 0.00002 * df["AnnualIncome"]
    - 0.25 * df["ExistingLoans"]
    - 0.15 * df["NumDependents"]
    + df["EmploymentStatus"].map({"Employed": 1.0, "Self-Employed": 0.5,
                                   "Retired": 0.3, "Unemployed": -1.5})
    + np.random.normal(0, 1.0, N)
)

threshold = np.percentile(latent, 35)  # ~35% "Bad" credit, 65% "Good"
df["Creditworthiness"] = np.where(latent > threshold, "Good", "Bad")

df.to_csv("data/credit_data.csv", index=False)
print(f"Generated data/credit_data.csv with {len(df)} rows.")
print(df["Creditworthiness"].value_counts(normalize=True).round(3))

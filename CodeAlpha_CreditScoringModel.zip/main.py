"""
main.py — run the full Credit Scoring Model pipeline end to end.

Usage:
    pip install -r requirements.txt
    python main.py
"""
import subprocess
import sys

print("Step 1/2: Generating dataset...")
subprocess.run([sys.executable, "src/generate_dataset.py"], check=True)

print("\nStep 2/2: Training & evaluating models...")
subprocess.run([sys.executable, "src/train_model.py"], check=True)

print("\nDone! Check the outputs/ folder for the comparison table, plots, "
      "and the saved model (best_model.pkl).")
